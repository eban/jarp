#! "c:/Program Files/Common Files/ruby" -v
#! ruby -v
puts $:
puts ARGV
