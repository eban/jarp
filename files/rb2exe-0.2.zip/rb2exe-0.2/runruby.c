#define  WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <unistd.h>
#include <process.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

char *
find_args(char *cmdline)
{
    int inquot = 0;
    char *line = cmdline;

    for (; *line; line++) {
	if (*line == '"') {
	    inquot = !inquot;
	    continue;
	}
	if (inquot)
	    continue;
	if (*line == ' ' || *line == '\t') {
	    line++;
	    break;
	}
    }
    return line;
}

char *
find_sharpbang(const char *myname)
{
    FILE *fp;
    static char buf[MAX_PATH * 2];

    fp = fopen(myname, "rb");
    if (!fp)
	return 0;
    while (fgets(buf, sizeof buf - 1, fp)) {
	char *last = buf + strlen(buf) - 1;
	if (buf[0] == '#' && buf[1] == '!' && *last == '\n') {
	    char *p = buf + 2;
	    if (*(last - 1) == '\r')
		last--;
	    *last = 0;
	    while (*p == ' ' || *p == '\t')
		p++;
	    return p;
	}
    }
    fclose(fp);
    return 0;
}

int
mainCRTStartup()
{
    char myname[MAX_PATH];
    char *newargl;
    char *cmdline;
    int pid;
    int stat;
    char *prog_name;
    char *sharpbang_args;
    char *p;

    GetModuleFileName(0, myname, sizeof myname - 1);
    for (p = myname; *p; p = CharNext(p)) {
	if (*p == '\\')
	    *p = '/';
    }

    prog_name = find_sharpbang(myname);
    if (!prog_name) {
	puts("script not found");
	exit(1);
    }

    cmdline = GetCommandLine();

    newargl = malloc(strlen(myname) + strlen(cmdline) + strlen(prog_name) + 10);
    if (!newargl)
	exit(1);
    sharpbang_args = find_args(prog_name);
    if (*sharpbang_args)
	*(sharpbang_args - 1) = 0;
    sprintf(newargl, "%s -x \"%s\" %s", prog_name, myname, find_args(cmdline));

    if (*prog_name == '"') {
	prog_name++;
	prog_name[strlen(prog_name) - 1] = 0;
    }
    pid = _spawnlp(_P_NOWAIT, prog_name, newargl, 0);
    if (pid == -1) {
	printf("%s: command not found", prog_name);
	stat = 1;
    } else
	_cwait(&stat, pid, WAIT_CHILD);
    exit(stat == 3 ? SIGABRT : stat);
}
