p File::basename($0, ".*")
